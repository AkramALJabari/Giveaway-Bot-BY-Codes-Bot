module.exports = {
    token: process.env.TOKEN,
    prefixering: process.env.PREFIX
}